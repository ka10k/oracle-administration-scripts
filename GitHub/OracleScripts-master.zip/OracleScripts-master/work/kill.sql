set ver off
set scan on

alter system kill session '&1,&2'
/

set ver on
