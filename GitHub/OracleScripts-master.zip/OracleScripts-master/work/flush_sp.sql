alter system flush shared_pool
/
