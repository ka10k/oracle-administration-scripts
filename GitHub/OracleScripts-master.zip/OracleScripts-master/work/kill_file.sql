
alter system kill session '2015, 6978';                                         
alter system kill session '2395,63737';                                         
alter system kill session '3376,18837';                                         
alter system kill session '3447,10426';                                         
alter system kill session '4154,11977';                                         
alter system kill session '855, 8638';                                          

6 rows selected.

