CURRENT DATABASE BLOCKING LOCKS                                                 
Alter system kill session '1012,31379';                                         
Alter system kill session '4486,49030';                                         
Alter system kill session '1183,36951';                                         
Alter system kill session '1106,24788';                                         
Alter system kill session '1084,24543';                                         
Alter system kill session '914,11589';                                          
Alter system kill session '1068,31179';                                         
Alter system kill session '1034,36723';                                         
Alter system kill session '1029,45459';                                         
