grant create session to oramon
/
grant select on dba_users to oramon
/
grant select on dba_data_files to oramon
/
grant select on dba_tablespaces to oramon
/
grant select on sys.sys_dba_segs to oramon
/
grant select on dba_tab_partitions to oramon
/
grant select on dba_ind_partitions to oramon
/
grant select on dba_free_space to oramon
/
grant execute on dbms_space_admin to oramon
/
grant execute on dbms_space to oramon
/
grant analyze any to oramon
/
