set linesize 101
set pagesize 30
set heading on
set ver off

set scan on

col sid        format a5
col ser#       format a5
col orauser    format a10
col program    format a25
col username   format a10
col osuser     format a10
col command    format a15
col S          format a1
col machine    format a10
col logon      format a11


select lpad(to_char(s.sid),5) sid,
      lpad(to_char(decode(sign(s.serial#), -1,
         65536+s.serial#, s.serial# )), 5) ser#,
      substr(s.username,1,10) orauser,
      substr(s.osuser,1,10) osuser,
      nvl(rpad(substr(upper(s.program),instr(s.program,'\',-1,1)+1,
      length(s.program)),25),'NOT DEFINED') program,
      substr(s.status,1,1) S,
      substr(a.name,1,15) command,
      substr(s.machine,instr(s.machine,'\',1,1)+1,
      length(s.machine)) machine,
      to_char(logon_time,'dd/mm hh24:mi') logon
  from v$session s, sys.audit_actions a
  where a.action = s.command  and s.sid = &1;

set scan off
set ver on
set feedback on