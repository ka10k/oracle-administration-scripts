select STATUS from v$datafile where file#=594
/

