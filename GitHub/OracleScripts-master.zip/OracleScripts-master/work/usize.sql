prompt User size (Mb)

select round(sum(bytes)/1024/1024,2) siz from user_segments
/

