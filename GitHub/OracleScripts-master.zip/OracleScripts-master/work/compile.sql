alter PACKAGE MTS24E.AC_ASSA compile BODY;                                                          
alter PACKAGE MTS24E.PYABUN_PCK compile BODY;                                                       
alter PROCEDURE MTS24E.DROP_CONTR_ADD compile ;                                                     

