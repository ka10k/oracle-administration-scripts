Input truncated to 9 characters
