Alter system kill session '3333,31086';/* Y004851 MTS24E*/                                
Alter system kill session '4582,21113';/* HLR53 MTS24E*/                                  
