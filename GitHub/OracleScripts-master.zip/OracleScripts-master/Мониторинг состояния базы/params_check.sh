mailto='sbrazgin@gmail.com'
mailto_info='sbrazgin@gmail.com'
host_desc='Portal_postavchikov'
instance_name='orcl'
sendmail=/usr/sbin/sendmail

oracle_user=TEST_CON
oracle_pass=xxx

export NLS_LANG=RUSSIAN_CIS.CL8MSWIN1251