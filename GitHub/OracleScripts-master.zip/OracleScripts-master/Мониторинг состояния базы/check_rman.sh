export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'

rman target / cmdfile commandfile1.rcv log rman_outfile.txt