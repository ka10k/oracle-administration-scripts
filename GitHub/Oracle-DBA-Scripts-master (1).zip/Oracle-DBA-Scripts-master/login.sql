set pagesize 300 linesize 400
col report format a400
def _editor=vi