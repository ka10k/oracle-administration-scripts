# PLSQL-demo-scripts
PL/SQL demo scripts

Steven Feuerstein  
https://twitter.com/sfonplsql

