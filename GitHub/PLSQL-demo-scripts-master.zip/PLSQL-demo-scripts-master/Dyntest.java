class Dyntest
{
  public static void main (String args [])
  {
     p.l (DynSQL.upd (args[0], args[1], args[2], args[3]));
  }
}
