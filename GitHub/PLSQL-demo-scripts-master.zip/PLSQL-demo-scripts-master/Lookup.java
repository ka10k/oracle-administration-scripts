interface Lookup {
   Object find (String name);
}