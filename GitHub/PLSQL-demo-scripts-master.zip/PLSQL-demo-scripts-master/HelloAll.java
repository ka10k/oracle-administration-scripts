public class HelloAll {
   public static void lotsaText (
      int count) {
      for (int i = 0; i < count; i++) {
         System.out.println (
            "Hello Hello Hello Hello Hello All!");
         }
	}
}
