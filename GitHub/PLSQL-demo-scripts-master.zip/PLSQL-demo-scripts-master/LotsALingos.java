class LotsALingos {
   public static void main (String args[]) {
      PuterLingo Java = new PuterLingo("Java");
      System.out.println (Java.name());
   }
}
