class TestTimer 
{
   public static void main (String args[])
   {
      Timer tmr = new Timer();
        
      tmr.start ();
      tmr.end ();
      tmr.showElapsed("chow");
   }
}