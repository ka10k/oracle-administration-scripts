CREATE OR REPLACE PROCEDURE my_procedure
IS
BEGIN
   DBMS_OUTPUT.put_line ( 'running my_procedure' );
END my_procedure;
/