class PuterLingo {
   private String mname;
   public PuterLingo (String name) {
      mname = name;
   }
   public String name () {
      return mname;
   }
} 
